"""Initialize the package"""

from .land_registry import UKLandClient